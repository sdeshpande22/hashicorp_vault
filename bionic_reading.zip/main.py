from fastapi import FastAPI, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import requests
from bs4 import BeautifulSoup
import re

app = FastAPI()

# Serve static files for CSS
app.mount("/static", StaticFiles(directory="static"), name="static")

# Render the HTML page as the root endpoint
@app.get("/", response_class=HTMLResponse)
async def get_form():
    with open("templates/index.html") as file:
        return HTMLResponse(content=file.read())

# Endpoint to handle "Bionic Reader" conversion for text input
@app.post("/convert")
async def convert_text(text: str = Form(...)):
    processed_text = process_bionic_reader(text)
    return {"bionic_text": processed_text}

# Endpoint to handle file upload
@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    if file.content_type != "text/plain":
        raise HTTPException(status_code=400, detail="Only text files are supported.")
    
    # Read and decode the uploaded file content
    text = await file.read()
    text = text.decode("utf-8")
    
    processed_text = process_bionic_reader(text)
    return {"bionic_text": processed_text}

# Endpoint to handle URL input
@app.post("/url")
async def fetch_url_content(url: str = Form(...)):
    try:
        # Fetch content from the URL
        response = requests.get(url)
        response.raise_for_status()
        
        # Parse and extract main text content from the HTML
        soup = BeautifulSoup(response.text, "html.parser")
        text = soup.get_text(separator=" ", strip=True)
        
        processed_text = process_bionic_reader(text)
        
        return {"bionic_text": processed_text}
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail="Failed to fetch the URL content.")

# Helper function to create a "Bionic Reader" effect
def process_bionic_reader(text):
    # Converts text to "Bionic Reader" format
    sentences = re.split(r'(?<=\.)\s*', text)  # Split text by sentences (assuming period separates them)
    bionic_sentences = []

    for sentence in sentences:
        bionic_sentence = " ".join(
            f"<b>{word[:len(word) // 2]}</b>{word[len(word) // 2:]}" for word in sentence.split()
        )
        bionic_sentences.append(bionic_sentence)

    return ". ".join(bionic_sentences)
