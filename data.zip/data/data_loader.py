"""
Data loading utilities for the Universal ML Workflow Template
Supports multiple data sources: seaborn, sklearn, CSV files, etc.
"""

import pandas as pd
import seaborn as sns
from sklearn import datasets
import os
from typing import Union, Dict, Any


class DataLoader:
    """Universal data loader supporting multiple data sources"""
    
    @staticmethod
    def load_data(source: str, dataset_name: str, **kwargs) -> pd.DataFrame:
        """
        Load data from various sources
        
        Args:
            source (str): Data source ('seaborn', 'sklearn', 'csv', 'json', 'excel', 'parquet', 'url')
            dataset_name (str): Name of the dataset or path to file
            **kwargs: Additional arguments for specific loaders
            
        Returns:
            pd.DataFrame: Loaded dataset
        """
        source_lower = source.lower()
        
        if source_lower == 'seaborn':
            return DataLoader._load_seaborn(dataset_name)
        elif source_lower == 'sklearn':
            return DataLoader._load_sklearn(dataset_name, **kwargs)
        elif source_lower in ['csv', 'file']:
            return DataLoader._load_csv(dataset_name, **kwargs)
        elif source_lower == 'json':
            return DataLoader._load_json(dataset_name, **kwargs)
        elif source_lower in ['excel', 'xlsx', 'xls']:
            return DataLoader._load_excel(dataset_name, **kwargs)
        elif source_lower == 'parquet':
            return DataLoader._load_parquet(dataset_name, **kwargs)
        elif source_lower == 'url':
            return DataLoader._load_url(dataset_name, **kwargs)
        else:
            supported_sources = ['seaborn', 'sklearn', 'csv', 'json', 'excel', 'parquet', 'url']
            raise ValueError(f"Unsupported data source: {source}. Supported sources: {supported_sources}")
    
    @staticmethod
    def _load_seaborn(dataset_name: str) -> pd.DataFrame:
        """Load dataset from seaborn"""
        try:
            return sns.load_dataset(dataset_name)
        except Exception as e:
            available_datasets = sns.get_dataset_names()
            raise ValueError(
                f"Failed to load seaborn dataset '{dataset_name}'. "
                f"Available datasets: {available_datasets[:10]}... "
                f"Error: {e}"
            )
    
    @staticmethod
    def _load_sklearn(dataset_name: str, **kwargs) -> pd.DataFrame:
        """Load dataset from sklearn"""
        try:
            if dataset_name == 'iris':
                data = datasets.load_iris(as_frame=True)
            elif dataset_name == 'wine':
                data = datasets.load_wine(as_frame=True)
            elif dataset_name == 'breast_cancer':
                data = datasets.load_breast_cancer(as_frame=True)
            elif dataset_name == 'diabetes':
                data = datasets.load_diabetes(as_frame=True)
            elif dataset_name == 'california_housing':
                data = datasets.fetch_california_housing(as_frame=True)
            elif dataset_name == 'boston':
                # Note: Boston housing dataset is deprecated
                raise ValueError("Boston housing dataset is deprecated. Use california_housing instead.")
            else:
                raise ValueError(f"Unsupported sklearn dataset: {dataset_name}")
            
            return data.frame
        except Exception as e:
            raise ValueError(f"Failed to load sklearn dataset '{dataset_name}'. Error: {e}")
    
    @staticmethod
    def _load_csv(file_path: str, **kwargs) -> pd.DataFrame:
        """Load dataset from CSV file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"CSV file not found: {file_path}")
        
        try:
            return pd.read_csv(file_path, **kwargs)
        except Exception as e:
            raise ValueError(f"Failed to load CSV file '{file_path}'. Error: {e}")
    
    @staticmethod
    def _load_url(url: str, **kwargs) -> pd.DataFrame:
        """Load dataset from URL"""
        try:
            return pd.read_csv(url, **kwargs)
        except Exception as e:
            raise ValueError(f"Failed to load data from URL '{url}'. Error: {e}")
    
    @staticmethod
    def _load_json(file_path: str, **kwargs) -> pd.DataFrame:
        """Load dataset from JSON file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"JSON file not found: {file_path}")
        
        try:
            return pd.read_json(file_path, **kwargs)
        except Exception as e:
            raise ValueError(f"Failed to load JSON file '{file_path}'. Error: {e}")
    
    @staticmethod
    def _load_excel(file_path: str, **kwargs) -> pd.DataFrame:
        """Load dataset from Excel file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        try:
            return pd.read_excel(file_path, **kwargs)
        except Exception as e:
            raise ValueError(f"Failed to load Excel file '{file_path}'. Error: {e}")
    
    @staticmethod
    def _load_parquet(file_path: str, **kwargs) -> pd.DataFrame:
        """Load dataset from Parquet file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Parquet file not found: {file_path}")
        
        try:
            return pd.read_parquet(file_path, **kwargs)
        except Exception as e:
            raise ValueError(f"Failed to load Parquet file '{file_path}'. Error: {e}")
    
    @staticmethod
    def get_available_datasets() -> Dict[str, list]:
        """Get list of available datasets from different sources"""
        available = {
            'seaborn': sns.get_dataset_names(),
            'sklearn': [
                'iris', 'wine', 'breast_cancer', 'diabetes', 
                'california_housing'
            ]
        }
        return available


def load_configured_dataset(config: Dict[str, Any]) -> pd.DataFrame:
    """
    Load dataset based on configuration with smart auto-detection
    
    Args:
        config (dict): Configuration containing dataset information
        
    Returns:
        pd.DataFrame: Loaded dataset
    """
    dataset_name = config.get('dataset_name')
    
    if not dataset_name:
        raise ValueError("No dataset specified in configuration. Please set 'dataset_name' in config file.")
    
    # Smart auto-detection
    df = smart_load_dataset(dataset_name)
    print(f"✅ Successfully loaded dataset: {dataset_name}")
    return df


def smart_load_dataset(dataset_name: str) -> pd.DataFrame:
    """
    Smart dataset loader that auto-detects the format and source
    
    Args:
        dataset_name (str): Dataset name or file path
        
    Returns:
        pd.DataFrame: Loaded dataset
    """
    # Check if it's a file path
    if os.path.exists(dataset_name) or dataset_name.startswith('http'):
        return _load_file_by_extension(dataset_name)
    
    # Try seaborn datasets first (most common)
    try:
        df = sns.load_dataset(dataset_name)
        print(f"📊 Loaded from seaborn: {dataset_name}")
        return df
    except:
        pass
    
    # Try sklearn datasets
    sklearn_datasets = {
        'iris': lambda: datasets.load_iris(as_frame=True).frame,
        'wine': lambda: datasets.load_wine(as_frame=True).frame,
        'breast_cancer': lambda: datasets.load_breast_cancer(as_frame=True).frame,
        'diabetes': lambda: datasets.load_diabetes(as_frame=True).frame,
        'california_housing': lambda: datasets.fetch_california_housing(as_frame=True).frame,
    }
    
    if dataset_name in sklearn_datasets:
        try:
            df = sklearn_datasets[dataset_name]()
            print(f"🔬 Loaded from sklearn: {dataset_name}")
            return df
        except Exception as e:
            pass
    
    # If nothing works, show helpful error
    available_seaborn = sns.get_dataset_names()
    available_sklearn = list(sklearn_datasets.keys())
    
    error_msg = f"Could not load dataset '{dataset_name}'.\n"
    error_msg += f"Available seaborn datasets: {available_seaborn[:5]}...\n"
    error_msg += f"Available sklearn datasets: {available_sklearn}\n"
    error_msg += f"Or provide a file path (CSV, JSON, Excel, Parquet) or URL"
    raise ValueError(error_msg)


def _load_file_by_extension(file_path: str) -> pd.DataFrame:
    """Load file based on its extension"""
    
    # Handle URLs
    if file_path.startswith('http'):
        try:
            df = pd.read_csv(file_path)
            print(f"🌐 Loaded from URL: {file_path}")
            return df
        except:
            try:
                df = pd.read_json(file_path)
                print(f"🌐 Loaded JSON from URL: {file_path}")
                return df
            except Exception as e:
                raise ValueError(f"Failed to load from URL '{file_path}'. Error: {e}")
    
    # Handle local files
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # Get file extension
    _, ext = os.path.splitext(file_path.lower())
    
    try:
        if ext in ['.csv']:
            df = pd.read_csv(file_path)
            print(f"📄 Loaded CSV: {file_path}")
        elif ext in ['.json']:
            df = pd.read_json(file_path)
            print(f"📄 Loaded JSON: {file_path}")
        elif ext in ['.xlsx', '.xls']:
            df = pd.read_excel(file_path)
            print(f"📄 Loaded Excel: {file_path}")
        elif ext in ['.parquet']:
            df = pd.read_parquet(file_path)
            print(f"📄 Loaded Parquet: {file_path}")
        else:
            # Try CSV as default
            df = pd.read_csv(file_path)
            print(f"📄 Loaded as CSV (default): {file_path}")
        
        return df
        
    except Exception as e:
        raise ValueError(f"Failed to load file '{file_path}'. Error: {e}")
