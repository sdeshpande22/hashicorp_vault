# Data loading and exploration utilities
"""
Utilities for loading data and performing exploratory data analysis
"""

import pandas as pd
import numpy as np
from sklearn.feature_selection import mutual_info_classif, mutual_info_regression, f_classif, f_regression
from sklearn.feature_selection import SelectKBest, VarianceThreshold
from scipy.stats import pearsonr


def load_data(file_path, file_type='csv'):
    """
    Universal data loader
    
    Args:
        file_path (str): Path to the data file
        file_type (str): Type of file ('csv', 'excel', 'json')
    
    Returns:
        pd.DataFrame: Loaded dataframe
    """
    if file_type == 'csv':
        return pd.read_csv(file_path)
    elif file_type == 'excel':
        return pd.read_excel(file_path)
    elif file_type == 'json':
        return pd.read_json(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")


def perform_universal_eda(df, target_col):
    """
    Universal EDA that works with any dataset
    
    Args:
        df (pd.DataFrame): Input dataframe
        target_col (str): Target column name
    
    Returns:
        tuple: (numerical_features, categorical_features)
    """
    print("="*60)
    print("STEP 3: EXPLORATORY DATA ANALYSIS")
    print("="*60)
    
    # Basic info
    print(f"Dataset shape: {df.shape}")
    print(f"Target column: {target_col}")
    
    # Missing values
    missing = df.isnull().sum()
    if missing.sum() > 0:
        print("\nMissing values:")
        print(missing[missing > 0])
    else:
        print("\n✓ No missing values found")
    
    # Target distribution
    if target_col in df.columns:
        print(f"\nTarget distribution:")
        print(df[target_col].value_counts())
    
    # Numerical features summary
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numerical_cols:
        numerical_cols.remove(target_col)
    
    if numerical_cols:
        print(f"\nNumerical features ({len(numerical_cols)}): {numerical_cols}")
        print(df[numerical_cols].describe())
    
    # Categorical features summary
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if categorical_cols:
        print(f"\nCategorical features ({len(categorical_cols)}): {categorical_cols}")
        for col in categorical_cols[:5]:  # Show first 5 categorical columns
            print(f"\n{col} - Unique values ({df[col].nunique()}): {df[col].value_counts().head().to_dict()}")
    
    return numerical_cols, categorical_cols


def select_features(df, target_col, exclude_cols=None, config=None):
    """
    Select relevant features for modeling with advanced selection methods
    
    Args:
        df (pd.DataFrame): Input dataframe
        target_col (str): Target column name
        exclude_cols (list): Columns to exclude
        config (dict): Configuration dictionary for feature selection settings
    
    Returns:
        tuple: (selected_feature_columns, dropped_columns_info)
    """
    print("="*60)
    print("STEP 5: FEATURE SELECTION")
    print("="*60)
    
    if exclude_cols is None:
        exclude_cols = []
    
    # Track all dropped columns with reasons
    dropped_columns_info = {
        'target_column': [target_col],
        'user_excluded': exclude_cols.copy(),
        'data_leakage': [],
        'high_cardinality': []
    }
    
    # Remove target and excluded columns
    all_cols = df.columns.tolist()
    feature_cols = [col for col in all_cols if col != target_col and col not in exclude_cols]
    
    # Check for data leakage - perfect correlation with target
    leakage_cols = []
    target_values = df[target_col]
    
    for col in feature_cols[:]:  # Copy list to avoid modification during iteration
        if df[col].dtype == 'object':
            # For categorical features, check if it perfectly predicts target
            crosstab = pd.crosstab(target_values, df[col])
            # Check if each target value maps to exactly one feature value
            if all(crosstab.sum(axis=1) == crosstab.max(axis=1)):
                leakage_cols.append(col)
                feature_cols.remove(col)
        elif df[col].dtype in ['int64', 'float64']:
            # For numerical features, check correlation (only if both are numeric)
            try:
                correlation = df[col].corr(target_values)
                if abs(correlation) > 0.99:  # Near perfect correlation
                    leakage_cols.append(col)
                    feature_cols.remove(col)
            except:
                # Skip correlation check if it fails
                pass
    
    dropped_columns_info['data_leakage'] = leakage_cols
    
    if leakage_cols:
        print(f"🚨 Excluded data leakage columns: {leakage_cols}")
    
    # Remove high-cardinality categorical features (>50 unique values)
    # Note: You can adjust this threshold based on your dataset needs
    cardinality_threshold = 50  # Default threshold - can be configured
    high_cardinality_cols = []
    
    print(f"\n🔍 CARDINALITY ANALYSIS (threshold: {cardinality_threshold}):")
    for col in feature_cols:
        if df[col].dtype == 'object':
            unique_count = df[col].nunique()
            if unique_count > cardinality_threshold:
                high_cardinality_cols.append(col)
                print(f"   ❌ {col}: {unique_count} unique values → DROPPED (high cardinality)")
            else:
                print(f"   ✅ {col}: {unique_count} unique values → kept (low cardinality)")
    
    if not any(df[col].dtype == 'object' for col in feature_cols):
        print("   No categorical features to analyze")
    
    feature_cols = [col for col in feature_cols if col not in high_cardinality_cols]
    dropped_columns_info['high_cardinality'] = high_cardinality_cols
    
    if high_cardinality_cols:
        print(f"⚠️ Excluded high-cardinality features: {high_cardinality_cols}")
    
    # Advanced Feature Selection Methods
    advanced_dropped_cols = []
    
    # Get configuration settings (with defaults)
    if config is None:
        config = {}
    
    # 1. Remove constant/quasi-constant features (low variance)
    if config.get('enable_variance_selection', True):
        variance_threshold = float(config.get('variance_threshold', 0.01))
        variance_dropped = remove_low_variance_features(df, feature_cols, variance_threshold)
        if variance_dropped:
            print(f"\n🔍 VARIANCE ANALYSIS (threshold: {variance_threshold}):")
            print(f"   ❌ Dropped low variance features: {variance_dropped}")
            feature_cols = [col for col in feature_cols if col not in variance_dropped]
            advanced_dropped_cols.extend(variance_dropped)
    
    # 2. Remove highly correlated features (collinearity)
    if config.get('enable_correlation_selection', True):
        correlation_threshold = float(config.get('correlation_threshold', 0.95))
        correlation_dropped = remove_correlated_features(df, feature_cols, correlation_threshold)
        if correlation_dropped:
            print(f"\n🔍 CORRELATION ANALYSIS (threshold: {correlation_threshold}):")
            print(f"   ❌ Dropped highly correlated features: {correlation_dropped}")
            feature_cols = [col for col in feature_cols if col not in correlation_dropped]
            advanced_dropped_cols.extend(correlation_dropped)
    
    # 3. Statistical feature selection (optional)
    if config.get('enable_statistical_selection', False):
        statistical_top_k = int(config.get('statistical_top_k', 20))
        statistical_method = config.get('statistical_method', 'auto')
        statistical_dropped = statistical_feature_selection(df, feature_cols, target_col, statistical_top_k, statistical_method)
        if statistical_dropped:
            print(f"\n🔍 STATISTICAL ANALYSIS (keep top {statistical_top_k}, method: {statistical_method}):")
            print(f"   ❌ Dropped low importance features: {statistical_dropped}")
            feature_cols = [col for col in feature_cols if col not in statistical_dropped]
            advanced_dropped_cols.extend(statistical_dropped)
    
    # Update dropped columns info
    dropped_columns_info['advanced_selection'] = advanced_dropped_cols
    
    # Print summary of all dropped columns
    all_dropped = (dropped_columns_info['target_column'] + 
                   dropped_columns_info['user_excluded'] + 
                   dropped_columns_info['data_leakage'] + 
                   dropped_columns_info['high_cardinality'] +
                   dropped_columns_info.get('advanced_selection', []))
    
    if len(all_dropped) > 1:  # More than just target column
        print(f"\n📋 DROPPED COLUMNS SUMMARY:")
        print(f"   Target column: {dropped_columns_info['target_column']}")
        if dropped_columns_info['user_excluded']:
            print(f"   User excluded: {dropped_columns_info['user_excluded']}")
        if dropped_columns_info['data_leakage']:
            print(f"   Data leakage: {dropped_columns_info['data_leakage']}")
        if dropped_columns_info['high_cardinality']:
            print(f"   High cardinality: {dropped_columns_info['high_cardinality']}")
        if dropped_columns_info.get('advanced_selection'):
            print(f"   Advanced selection: {dropped_columns_info['advanced_selection']}")
        print(f"   Total dropped: {len(all_dropped)} columns")
    
    print(f"✓ Selected {len(feature_cols)} features for modeling")
    print(f"Features: {feature_cols}")
    
    return feature_cols, dropped_columns_info


def remove_low_variance_features(df, feature_cols, threshold=0.01):
    """
    Remove features with low variance (constant or quasi-constant features)
    
    Args:
        df (pd.DataFrame): Input dataframe
        feature_cols (list): List of feature columns to analyze
        threshold (float): Variance threshold (default: 0.01)
    
    Returns:
        list: List of dropped features
    """
    dropped_features = []
    
    # Only analyze numerical features for variance
    numerical_features = [col for col in feature_cols if df[col].dtype in ['int64', 'float64']]
    
    if not numerical_features:
        return dropped_features
    
    # Use VarianceThreshold from sklearn
    try:
        selector = VarianceThreshold(threshold=threshold)
        selector.fit(df[numerical_features])
        
        # Get features that don't meet threshold
        low_variance_mask = ~selector.get_support()
        dropped_features = [numerical_features[i] for i in range(len(numerical_features)) if low_variance_mask[i]]
        
        if dropped_features:
            for feature in dropped_features:
                variance = df[feature].var()
                print(f"      • {feature}: variance = {variance:.6f} (< {threshold})")
    
    except Exception as e:
        print(f"      ⚠️ Variance analysis failed: {e}")
    
    return dropped_features


def remove_correlated_features(df, feature_cols, correlation_threshold=0.95):
    """
    Remove highly correlated features to reduce multicollinearity
    
    Args:
        df (pd.DataFrame): Input dataframe
        feature_cols (list): List of feature columns to analyze
        correlation_threshold (float): Correlation threshold (default: 0.95)
    
    Returns:
        list: List of dropped features
    """
    dropped_features = []
    
    # Only analyze numerical features for correlation
    numerical_features = [col for col in feature_cols if df[col].dtype in ['int64', 'float64']]
    
    if len(numerical_features) < 2:
        return dropped_features
    
    try:
        # Calculate correlation matrix
        corr_matrix = df[numerical_features].corr().abs()
        
        # Find pairs of highly correlated features
        high_corr_pairs = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                if corr_matrix.iloc[i, j] > correlation_threshold:
                    col1, col2 = corr_matrix.columns[i], corr_matrix.columns[j]
                    high_corr_pairs.append((col1, col2, corr_matrix.iloc[i, j]))
        
        # Drop one feature from each highly correlated pair
        already_dropped = set()
        for col1, col2, corr_value in high_corr_pairs:
            if col1 not in already_dropped and col2 not in already_dropped:
                # Drop the second feature (arbitrary choice)
                dropped_features.append(col2)
                already_dropped.add(col2)
                print(f"      • {col2}: corr({col1}, {col2}) = {corr_value:.3f} (> {correlation_threshold})")
    
    except Exception as e:
        print(f"      ⚠️ Correlation analysis failed: {e}")
    
    return dropped_features


def statistical_feature_selection(df, feature_cols, target_col, top_k=20, method='auto'):
    """
    Select top K features based on statistical tests
    
    Args:
        df (pd.DataFrame): Input dataframe
        feature_cols (list): List of feature columns
        target_col (str): Target column name
        top_k (int): Number of top features to keep
        method (str): 'auto', 'f_test', 'mutual_info'
    
    Returns:
        list: List of dropped features
    """
    dropped_features = []
    
    if len(feature_cols) <= top_k:
        return dropped_features
    
    try:
        # Prepare features and target
        X = df[feature_cols]
        y = df[target_col]
        
        # Handle mixed data types - convert categorical to numerical for analysis
        X_processed = X.copy()
        for col in X.columns:
            if X[col].dtype == 'object':
                X_processed[col] = pd.Categorical(X[col]).codes
        
        # Fill missing values
        X_processed = X_processed.fillna(X_processed.mean())
        
        # Determine if classification or regression
        is_classification = y.dtype == 'object' or y.nunique() < 20
        
        # Choose statistical test
        if method == 'auto':
            if is_classification:
                selector = SelectKBest(score_func=f_classif, k=top_k)
            else:
                selector = SelectKBest(score_func=f_regression, k=top_k)
        elif method == 'mutual_info':
            if is_classification:
                selector = SelectKBest(score_func=mutual_info_classif, k=top_k)
            else:
                selector = SelectKBest(score_func=mutual_info_regression, k=top_k)
        else:  # f_test
            if is_classification:
                selector = SelectKBest(score_func=f_classif, k=top_k)
            else:
                selector = SelectKBest(score_func=f_regression, k=top_k)
        
        # Fit selector
        selector.fit(X_processed, y)
        
        # Get features that were not selected
        selected_mask = selector.get_support()
        dropped_features = [feature_cols[i] for i in range(len(feature_cols)) if not selected_mask[i]]
        
        if dropped_features:
            scores = selector.scores_
            for i, feature in enumerate(feature_cols):
                if not selected_mask[i]:
                    print(f"      • {feature}: score = {scores[i]:.3f}")
    
    except Exception as e:
        print(f"      ⚠️ Statistical feature selection failed: {e}")
    
    return dropped_features
