# Data preprocessing utilities
"""
Data preprocessing and pipeline creation utilities
"""

from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd
import numpy as np


class MultiColumnLabelEncoder(BaseEstimator, TransformerMixin):
    """
    Label encoder that works with multiple columns in sklearn pipelines
    """
    def __init__(self):
        self.encoders = {}
    
    def fit(self, X, y=None):
        X = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X
        for col in X.columns:
            le = LabelEncoder()
            # Handle missing values by treating them as a separate category
            X_col = X[col].fillna('missing_value')
            le.fit(X_col)
            self.encoders[col] = le
        return self
    
    def transform(self, X):
        X = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X
        X_transformed = X.copy()
        for col in X.columns:
            if col in self.encoders:
                X_col = X[col].fillna('missing_value')
                # Handle unseen categories
                le = self.encoders[col]
                mask = X_col.isin(le.classes_)
                X_transformed.loc[mask, col] = le.transform(X_col[mask])
                X_transformed.loc[~mask, col] = -1  # Assign -1 to unseen categories
        return X_transformed.values


def create_smart_preprocessing_pipeline(numerical_features, categorical_features, df=None, high_cardinality_threshold=10):
    """
    Create intelligent preprocessing pipeline that chooses between OneHot and Label encoding
    
    Args:
        numerical_features (list): List of numerical feature names
        categorical_features (list): List of categorical feature names
        df (pd.DataFrame): Original dataframe to analyze cardinality
        high_cardinality_threshold (int): Threshold for using LabelEncoder vs OneHotEncoder
    
    Returns:
        ColumnTransformer: Preprocessing pipeline
    """
    print("="*60)
    print("STEP 4: SMART DATA PREPROCESSING")
    print("="*60)
    
    # Create transformers
    transformers = []
    
    if numerical_features:
        # Create pipeline for numerical features: impute -> scale
        numerical_transformer = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        transformers.append(('num', numerical_transformer, numerical_features))
        print(f"✓ Numerical transformer created for {len(numerical_features)} features (with imputation)")
    
    if categorical_features and df is not None:
        # Separate categorical features by cardinality
        low_cardinality_features = []
        high_cardinality_features = []
        
        for feature in categorical_features:
            unique_count = df[feature].nunique()
            if unique_count <= high_cardinality_threshold:
                low_cardinality_features.append(feature)
            else:
                high_cardinality_features.append(feature)
        
        print(f"Categorizing features with threshold: {high_cardinality_threshold}")
        print(f"Low cardinality (≤{high_cardinality_threshold}): {[(f, df[f].nunique()) for f in low_cardinality_features]}")
        print(f"High cardinality (>{high_cardinality_threshold}): {[(f, df[f].nunique()) for f in high_cardinality_features]}")
        
        # OneHotEncoder for low cardinality features
        if low_cardinality_features:
            categorical_transformer_onehot = Pipeline([
                ('imputer', SimpleImputer(strategy='most_frequent')),
                ('encoder', OneHotEncoder(handle_unknown='ignore', drop='first'))
            ])
            transformers.append(('cat_onehot', categorical_transformer_onehot, low_cardinality_features))
            print(f"✓ OneHotEncoder for {len(low_cardinality_features)} low-cardinality features (≤{high_cardinality_threshold} categories)")
            for feature in low_cardinality_features:
                print(f"   • {feature}: {df[feature].nunique()} categories")
        
        # LabelEncoder for high cardinality features
        if high_cardinality_features:
            categorical_transformer_label = Pipeline([
                ('imputer', SimpleImputer(strategy='most_frequent')),
                ('encoder', MultiColumnLabelEncoder())
            ])
            transformers.append(('cat_label', categorical_transformer_label, high_cardinality_features))
            print(f"✓ LabelEncoder for {len(high_cardinality_features)} high-cardinality features (>{high_cardinality_threshold} categories)")
            for feature in high_cardinality_features:
                print(f"   • {feature}: {df[feature].nunique()} categories → will be encoded as integers")
    
    elif categorical_features:
        # Fallback to OneHotEncoder if no dataframe provided
        categorical_transformer = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('encoder', OneHotEncoder(handle_unknown='ignore', drop='first'))
        ])
        transformers.append(('cat', categorical_transformer, categorical_features))
        print(f"✓ OneHotEncoder (fallback) for {len(categorical_features)} features")
    
    # Create preprocessor
    if transformers:
        preprocessor = ColumnTransformer(transformers=transformers, remainder='passthrough')
        print("✓ Smart preprocessing pipeline created")
        return preprocessor
    else:
        print("⚠️ No features to preprocess")
        return None


def create_preprocessing_pipeline(numerical_features, categorical_features):
    """
    Create preprocessing pipeline for numerical and categorical features
    
    Args:
        numerical_features (list): List of numerical feature names
        categorical_features (list): List of categorical feature names
    
    Returns:
        ColumnTransformer: Preprocessing pipeline
    """
    print("="*60)
    print("STEP 4: DATA PREPROCESSING")
    print("="*60)
    
    # Create transformers
    transformers = []
    
    if numerical_features:
        # Create pipeline for numerical features: impute -> scale
        numerical_transformer = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        transformers.append(('num', numerical_transformer, numerical_features))
        print(f"✓ Numerical transformer created for {len(numerical_features)} features (with imputation)")
    
    if categorical_features:
        # Create pipeline for categorical features: impute -> encode
        categorical_transformer = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('encoder', OneHotEncoder(handle_unknown='ignore', drop='first'))
        ])
        transformers.append(('cat', categorical_transformer, categorical_features))
        print(f"✓ Categorical transformer created for {len(categorical_features)} features (with imputation)")
    
    # Create preprocessor
    if transformers:
        preprocessor = ColumnTransformer(transformers=transformers)
        print("✓ Preprocessing pipeline created")
        return preprocessor
    else:
        print("⚠️ No features to preprocess")
        return None


def split_data(df, feature_cols, target_col, test_size=0.2, random_state=42):
    """
    Split data into training and testing sets
    
    Args:
        df (pd.DataFrame): Input dataframe
        feature_cols (list): Feature column names
        target_col (str): Target column name
        test_size (float): Test set size ratio
        random_state (int): Random state for reproducibility
    
    Returns:
        tuple: (X_train, X_test, y_train, y_test, is_classification)
    """
    print("="*60)
    print("STEP 6: TRAIN-TEST SPLIT")
    print("="*60)
    
    X = df[feature_cols]
    y = df[target_col]
    
    # Check if classification or regression
    is_classification = y.dtype == 'object' or y.nunique() < 20
    
    if is_classification and y.nunique() > 1:
        # Stratified split for classification
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        print("✓ Stratified split performed (classification)")
    else:
        # Regular split for regression or single class
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state
        )
        print("✓ Regular split performed (regression)")
    
    print(f"Training set: {X_train.shape}")
    print(f"Test set: {X_test.shape}")
    
    return X_train, X_test, y_train, y_test, is_classification
