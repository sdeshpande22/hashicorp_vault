def addition(a,b):
    return a+b

def substraction(a,b):
    return a-b

